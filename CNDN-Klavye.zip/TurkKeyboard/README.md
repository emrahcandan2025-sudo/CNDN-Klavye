# CNDN Klavye

Ekran görüntüsündeki koyu temalı Türkçe klavyeye benzeyen, kaydırarak yazma
(swipe typing) ve emoji paneli olan basit bir Android klavye uygulaması
(Input Method Editor / IME). Kotlin ile yazılmıştır, harici kütüphane
gerektirmez.

## Özellikler
- Türkçe QWERTY tuş düzeni (Ğ Ü Ş İ Ö Ç dahil), koyu tema
- Büyük/küçük harf (shift), rakam/sembol modu
- **Kaydırarak yazma**: Parmağını harflerin üzerinde gezdirip bırakınca,
  gömülü Türkçe sözlükten en olası 3 kelime öneri çubuğunda çıkar; birine
  dokununca yazılır.
- **Emoji paneli**: Kategori sekmeleriyle (yüz, hayvan, yiyecek, spor/nesne,
  semboller) emoji ekleme.

## Nasıl derlenir
1. [Android Studio](https://developer.android.com/studio) kur (Hedgehog/Koala
   veya üzeri önerilir).
2. Bu klasörü **File > Open** ile Android Studio'da aç. Studio, Gradle
   wrapper'ı (gradlew) otomatik oluşturacaktır; ilk açılışta "Sync Now" de.
3. Bir emülatör veya gerçek cihaz seçip **Run ▶** ile yükle.

## Cihazda etkinleştirme
1. Uygulamayı aç, **"Klavyeyi Etkinleştir"** butonuna bas → sistem
   Ayarlar > Diller ve Giriş > Ekran Klavyeleri ekranına gider, **CNDN
   Klavye**'yi aç.
2. Ana ekrana dön, **"Klavyeyi Seç"** butonuna bas ve listeden **CNDN
   Klavye**'yi seç. Artık herhangi bir metin alanında bu klavye açılır.

## Proje yapısı
```
app/src/main/java/com/cndn/ime/
├── MainActivity.kt       # Ayarlar ekranı (etkinleştir / seç)
├── KeyboardService.kt    # InputMethodService - ana klavye servisi
├── KeyboardView.kt       # Tuşları çizen ve dokunma/kaydırmayı yöneten view
├── EmojiPanel.kt         # Emoji sekmeleri ve ızgarası
├── TurkishLayout.kt      # Türkçe QWERTY tuş dizilimi
├── Dictionary.kt         # Kaydırma önerileri için gömülü kelime listesi
├── SwipeEngine.kt        # Kaydırma yolunu kelimeyle eşleştiren algoritma
└── Key.kt                # Tuş veri modeli
```

## Bilinen sınırlamalar / geliştirilebilecekler
- Sözlük küçük ve koda gömülü (`Dictionary.kt`); gerçek kullanım için
  `assets/` altına büyük bir Türkçe kelime listesi (ör. 50.000+ kelime)
  eklenip dosyadan okunmalı.
- Kaydırma algoritması basit bir benzerlik skoruna dayanıyor; daha isabetli
  sonuç için tuş-koordinatlarına dayalı bir "keyboard decoder" (ör. Levenshtein
  + tuş mesafesi ağırlıklı) eklenebilir.
- Uzun basılı tuş tekrarı (backspace'i basılı tutunca sürekli silme) henüz yok.
- Tuşlara basınca küçük "key preview" balonu (büyük harf önizlemesi) yok.
- Karanlık/aydınlık tema otomatik geçişi yok; renkler `colors.xml` ve
  `KeyboardView`/`EmojiPanel` içindeki `Color.parseColor` satırlarında sabit.

## GitHub'a yükleme
```bash
cd TurkKeyboard
git init
git add .
git commit -m "CNDN Klavye - ilk sürüm"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/cndn-klavye.git
git push -u origin main
```
