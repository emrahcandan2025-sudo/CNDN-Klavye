package com.cndn.ime

/** Klavye tuşu türleri */
enum class KeyType { CHAR, SHIFT, BACKSPACE, SPACE, ENTER, SYMBOLS, EMOJI, COMMA_PERIOD }

/**
 * Tek bir tuşu temsil eder. [label] ekranda gösterilen metin,
 * [code] karakter tuşları için gerçek karakter kodudur (-1 özel tuşlarda).
 * [weight] satır içindeki göreceli genişliktir (1f = normal tuş genişliği).
 */
data class Key(
    val label: String,
    val type: KeyType,
    val code: Int = -1,
    val weight: Float = 1f
) {
    // Ekrana çizilirken doldurulan gerçek konum/boyut bilgisi
    var x: Float = 0f
    var y: Float = 0f
    var width: Float = 0f
    var height: Float = 0f

    fun contains(px: Float, py: Float): Boolean =
        px >= x && px <= x + width && py >= y && py <= y + height

    fun centerX() = x + width / 2f
    fun centerY() = y + height / 2f
}
