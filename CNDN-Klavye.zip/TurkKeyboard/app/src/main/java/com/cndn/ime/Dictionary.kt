package com.cndn.ime

/**
 * Kaydırarak yazma (swipe) motoru için gömülü, küçük ama sık kullanılan
 * Türkçe kelimelerden oluşan bir sözlük. Gerçek bir üründe bu liste
 * cihazdaki büyük bir sözlük dosyasından (ör. assets/tr_words.txt) yüklenir;
 * burada bağımlılık gerektirmesin diye kod içine gömülü tutuldu.
 */
object Dictionary {
    val words: List<String> = listOf(
        "merhaba", "nasılsın", "iyiyim", "teşekkürler", "evet", "hayır",
        "tamam", "kaç", "saat", "bugün", "yarın", "dün", "lütfen", "affedersin",
        "görüşürüz", "selam", "naber", "güzel", "iyi", "kötü", "hızlı", "yavaş",
        "ev", "iş", "okul", "araba", "telefon", "bilgisayar", "internet",
        "arkadaş", "aile", "anne", "baba", "kardeş", "sevgili", "aşk",
        "para", "zaman", "hayat", "dünya", "gün", "gece", "sabah", "akşam",
        "kahve", "çay", "su", "yemek", "kitap", "müzik", "film", "oyun",
        "gel", "git", "gelecek", "gitti", "yapıyorum", "yapacağım", "istiyorum",
        "seviyorum", "biliyorum", "bilmiyorum", "anladım", "anlamadım",
        "nerede", "neden", "nasıl", "kim", "ne", "hangi", "kaça", "kaçta",
        "buyur", "rica", "özür", "dilerim", "hoşça", "kal", "kalın", "sağlık",
        "mesaj", "yazı", "cevap", "soru", "cevapla", "bekle", "acil", "önemli"
    )
}
